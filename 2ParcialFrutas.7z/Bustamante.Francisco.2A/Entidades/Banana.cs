using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{

    public class Banana : Fruta
    {
      #region Atributes
    protected string _paisOrigen;
    #endregion

      #region Properties
    public override bool TieneCarozo {

            get { return false; }
        
        }

        public string Nombre {

            get { return "Banana"; }
        
        }
    #endregion

      #region Builder
    public Banana(string color, float peso,  string origen) : base(peso, color) {

            this._paisOrigen = origen;

        }
    #endregion

      #region Overrides
    protected override string FrutaToString() {

            StringBuilder sb = new StringBuilder();

            sb.Append(base.FrutaToString());
            sb.Append(" --- ");
            sb.Append(this.Nombre);
            sb.Append(" --- ");
            sb.Append(this._paisOrigen);
            sb.Append(" --- ");
            sb.Append(this.TieneCarozo == true ? "SI" : "NO");

            return sb.ToString();

        }

        public override string ToString() {

            return this.FrutaToString();
        
        }
    #endregion

  }

}
