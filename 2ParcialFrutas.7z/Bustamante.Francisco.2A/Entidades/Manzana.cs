using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Threading.Tasks;
using Interfaces;

namespace Entidades
{
    public class Manzana : Fruta, ISerializar
    {
    #region Atributes
    protected string _provinciaOrigen;
    #endregion

    #region Properties
    public override bool TieneCarozo {

            get { return true; }

        }

        public string Nombre {

            get { return "Manzana"; }

        }

        public string RutaArchivo {

            get { return Environment.GetFolderPath(Environment.SpecialFolder.Desktop); }
            set { ;}

        }
    #endregion

    #region Builder
    public Manzana(string color,float peso , string provincia) : base(peso, color) {

            this._provinciaOrigen = provincia;

        }
    #endregion

    #region xml
    public bool Xml(string ruta) {

            try {

                TextWriter tw = new StreamWriter(this.RutaArchivo+ruta);
                XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
                serializador.Serialize(tw, this);
                tw.Close();
                return true;

            }
            catch (Exception) {

                return false;

            }

        }

        public bool Deserializar() {

            Manzana aux;

            try {	        
		
                TextReader tr = new StreamReader(this.RutaArchivo);
                XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
                aux = (Manzana)serializador.Deserialize(tr);
                tr.Close();

                return true;

	        } catch (Exception) {
 
		        return false;
            
            }

        }
    #endregion

    #region Overrides
    protected override string FrutaToString()
        {

            StringBuilder sb = new StringBuilder();

            sb.Append(base.FrutaToString());
            sb.Append(" --- ");
            sb.Append(this.Nombre);
            sb.Append(" --- ");
            sb.Append(this._provinciaOrigen);
            sb.Append(" --- ");
            sb.Append(this.TieneCarozo == true ? "SI" : "NO");

            return sb.ToString();

        }

        public override string ToString() {

            return this.FrutaToString();

        }
    #endregion

    }

}
