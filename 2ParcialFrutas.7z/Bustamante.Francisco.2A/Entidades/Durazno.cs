using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using Interfaces;

namespace Entidades
{
    public class Durazno : Fruta
    {

      #region Atributes
    protected int _cantPelusa;
    #endregion

      #region Properties
    public override bool TieneCarozo
    {

      get { return true; }

    }

    public string Nombre
    {

      get { return "Durazno"; }

    }

    public string RutaArchivo
    {

      get { return AppDomain.CurrentDomain.BaseDirectory + @"\Durazno.xml"; }
      set {; }

    }
    #endregion
  
      #region Builder
    public Durazno(string color, double peso, int pelusa) : base(peso, color)
    {

      this._cantPelusa = pelusa;

    }
    #endregion

      /*#region xml
    public bool SerializarXML()
    {

      try
      {

        TextWriter tw = new StreamWriter(this.RutaArchivo);
        XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
        serializador.Serialize(tw, this);
        tw.Close();
        return true;

      }
      catch (Exception)
      {

        return false;

      }

    }

    public bool Deserializar()
    {

      Manzana aux;

      try
      {

        TextReader tr = new StreamReader(this.RutaArchivo);
        XmlSerializer serializador = new XmlSerializer(typeof(Manzana));
        aux = (Manzana)serializador.Deserialize(tr);
        tr.Close();

        return true;

      }
      catch (Exception)
      {

        return false;

      }

    }
    #endregion*/

      #region Overrides
      protected override string FrutaToString()
      {

        StringBuilder sb = new StringBuilder();

        sb.Append(base.FrutaToString());
        sb.Append(" --- ");
        sb.Append(this.Nombre);
        sb.Append(" --- ");
        sb.Append(this._cantPelusa);
        sb.Append(" --- ");
        sb.Append(this.TieneCarozo == true ? "SI" : "NO");

        return sb.ToString();

      }

      public override string ToString()
      {

        return this.FrutaToString();

      }
      #endregion

    }
}
